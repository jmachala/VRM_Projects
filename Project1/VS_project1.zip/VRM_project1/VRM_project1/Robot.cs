﻿using System;
using System.Threading;
using ABB.Robotics.Controllers;
using ABB.Robotics.Controllers.Discovery;
using ABB.Robotics.Controllers.RapidDomain;


namespace VRM_project1
{
    class Robot
    {
     Controller con;
     private NetworkScanner scanner;
     Num pick_color;
     int send;

        static void Main()
        {
         Robot start = new Robot();
        }

        /* Hledání a připojení ke kontroleru / Vytvoření TCP Serveru */


        public Robot()
        {

            scanner = new NetworkScanner();
            scanner.Scan();
            ControllerInfoCollection Controllers = scanner.Controllers;

            foreach (ControllerInfo info in Controllers)
            {
                con = ControllerFactory.CreateFrom(info);

                    if (info.Availability == Availability.Available)
                    {
                        con.Logon(UserInfo.DefaultUser);
                        this.main_start_app();
                    }
                
            }
        }



        public void main_start_app()
        {    
                try
                {
                    if (con.OperatingMode == ControllerOperatingMode.Auto)
                    {
                        using (Mastership m = Mastership.Request(con.Rapid))
                        {

                        Thread test_t = new Thread(new ThreadStart(abb_send));
                        test_t.Start();

                        Thread test_t1 = new Thread(new ThreadStart(abb_read));
                        test_t1.Start();

                        //con.Rapid.Start(true);
                        }
                    }
                }
                catch (System.Exception)
                {
                }


        }


        public void abb_send()
        {
            while (true)
            {
             this.send_abb_thread();
            }
        }

        public void abb_read()
        {
            while (true)
            {
             this.abb_read_thread();
            }
        }


        public void send_abb_thread()
        {

            if(pick_color == 1)
            {
                Console.WriteLine("Pick color :");
                Console.WriteLine("0 = blue");
                Console.WriteLine("1 = red");
                Console.WriteLine("2 = orange");

                string color = Console.ReadLine();

                int color_int = int.Parse(color);

                send = 0;

                if (color_int == 0  || color_int == 1 || color_int == 2)
                {
                    send = 1;
                }
                else
                {
                 Console.WriteLine("Wrong, Pick again");
                }





                if (send == 1)
                {

                     try
                     {
                         if (con.OperatingMode == ControllerOperatingMode.Auto)
                         {
                            RapidData abb_color = con.Rapid.GetRapidData("T_ROB2", "Module1", "color");
                            RapidData wait_vs = con.Rapid.GetRapidData("T_ROB2", "Module1", "WAIT_FOR_VS");

                            Num color_send = Num.Parse(color);
                            Num vs_wait = Num.Parse("0");


                            using (Mastership master = Mastership.Request(con.Rapid))
                             {

                                abb_color.Value = color_send;
                                wait_vs.Value = vs_wait;

                             }
                         }
                     }
                     catch (System.Exception)
                     {
                     }
                 Thread.Sleep(1000);

                }




            }


        }

        public void abb_read_thread()
        {

         Thread.Sleep(500);

            try
            {
                if (con.OperatingMode == ControllerOperatingMode.Auto)
                {
                    RapidData VS_PICK = con.Rapid.GetRapidData("T_ROB2", "Module1", "VS_PICK");

                    pick_color = (Num)VS_PICK.Value;

                }
            }



            catch (System.Exception)
            {

            }
        }


    }
}   
